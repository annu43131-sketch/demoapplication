package com.example.demoapplication.controller;

import com.example.demoapplication.model.Product;
import com.example.demoapplication.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class ProductWebController {

    @Autowired
    private ProductRepository repository;

    // Show products page
    @GetMapping("/products-page")
    public String getProductsPage(Model model) {
        List<Product> products = repository.findAll();
        model.addAttribute("products", products);

        // Chart data
        List<String> names = products.stream().map(Product::getName).collect(Collectors.toList());
        List<Integer> quantities = products.stream().map(Product::getQuantity).collect(Collectors.toList());

        model.addAttribute("productNames", names);
        model.addAttribute("productQuantities", quantities);

        return "products";
    }

    // Add product
    @PostMapping("/products-page")
    public String addProduct(@ModelAttribute Product product) {
        repository.save(product);
        return "redirect:/products-page";
    }

    // Edit product form
    @GetMapping("/products-page/edit/{id}")
    public String editProductForm(@PathVariable Long id, Model model) {
        Product product = repository.findById(id).orElseThrow();
        model.addAttribute("product", product);
        return "edit"; // loads edit.html
    }

    // Update product
    @PostMapping("/products-page/edit/{id}")
    public String updateProduct(@PathVariable Long id, @ModelAttribute Product product) {
        product.setId(id);
        repository.save(product);
        return "redirect:/products-page";
    }

    // Delete product
    @GetMapping("/products-page/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        repository.deleteById(id);
        return "redirect:/products-page";
    }
}
